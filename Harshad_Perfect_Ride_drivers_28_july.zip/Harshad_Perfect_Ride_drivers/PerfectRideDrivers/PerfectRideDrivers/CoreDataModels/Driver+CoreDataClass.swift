//
//  Driver+CoreDataClass.swift
//  PerfectRideDrivers
//
//  Created by Company Name.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//

import Foundation
import CoreData

@objc(Driver)
public class Driver: NSManagedObject {
    
    class func getDriverInfoFromContext(params:NSPredicate?,sortOn:String? = nil ,isAsending:Bool? = nil) -> [AnyObject]? {
        var sortAry = [NSSortDescriptor]()
        if let sortKey = sortOn {
            let sortDesc = NSSortDescriptor(key: sortKey, ascending: isAsending!, selector:#selector(NSString.localizedCaseInsensitiveCompare(_:)))
            sortAry = [sortDesc]
        }
        return self.getDriverSortArrayFromContext(params: params, sortDescAry: sortAry as NSArray?)
    }
    
    class func getDriverSortArrayFromContext(params:NSPredicate?,sortDescAry:NSArray? = nil) -> [AnyObject]? {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Driver")
        if let predict = params {
            fetchRequest.predicate = predict
        }
        
        let context = APP_DELEGATE.managedObjectContext
        
        let entity = NSEntityDescription.entity(forEntityName: "Driver", in: (context))
        fetchRequest.entity = entity
        
        if let sortKey = sortDescAry {
            fetchRequest.sortDescriptors = sortKey as? [NSSortDescriptor]
        }
        do {
            let fetchedDreams = try context.fetch(fetchRequest)
            if fetchedDreams.count > 0 {
                return fetchedDreams as [AnyObject]?
            } else {
                return nil
            }
        } catch {
            return nil
        }
    }
    
    class func addNewRecoredInDB(_ driverDetails: [String : String], driver: Driver){
        driver.driverId = driverDetails["driverId"]
        driver.expiry = driverDetails["expiry"]
        driver.licenseNumber = driverDetails["licenseNumber"]
        APP_DELEGATE.saveContext()
    }
    
    class func saveDriverDetailsInDB(_ driverDetails: [String : String], isForEdit: Bool = false){
        let predicate = NSPredicate(format: "driverId == '\(driverDetails["driverId"] ?? "0")'")
        var driver: Driver!
        if let arrDriverList = Driver.getDriverInfoFromContext(params: predicate), arrDriverList.count > 0 {
            driver = arrDriverList.first as? Driver
        }else{
            if !isForEdit{
                let context = APP_DELEGATE.managedObjectContext
                let entity = NSEntityDescription.entity(forEntityName: "Driver", in: (context))
                driver = Driver(entity: entity!, insertInto: context)
            }
        }
        if driver != nil{
            Driver.addNewRecoredInDB(driverDetails, driver: driver)
        }
    }
    
}
