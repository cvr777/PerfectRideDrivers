//
//  User+CoreDataClass.swift
//  PerfectRideDrivers
//
//  Created by Company Name.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//
//

import Foundation
import CoreData

@objc(User)
public class User: NSManagedObject {
    
    class func getUserInfoFromContext(params:NSPredicate?,sortOn:String? = nil ,isAsending:Bool? = nil) -> [AnyObject]? {
        var sortAry = [NSSortDescriptor]()
        if let sortKey = sortOn {
            let sortDesc = NSSortDescriptor(key: sortKey, ascending: isAsending!, selector:#selector(NSString.localizedCaseInsensitiveCompare(_:)))
            sortAry = [sortDesc]
        }
        return self.getUserSortArrayFromContext(params: params, sortDescAry: sortAry as NSArray?)
    }
    
    class func getUserSortArrayFromContext(params:NSPredicate?,sortDescAry:NSArray? = nil) -> [AnyObject]? {
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "User")
        if let predict = params {
            fetchRequest.predicate = predict
        }
        
        let context = APP_DELEGATE.managedObjectContext
        
        let entity = NSEntityDescription.entity(forEntityName: "User", in: (context))
        fetchRequest.entity = entity
        
        if let sortKey = sortDescAry {
            fetchRequest.sortDescriptors = sortKey as? [NSSortDescriptor]
        }
        do {
            let fetchedDreams = try context.fetch(fetchRequest)
            if fetchedDreams.count > 0 {
                return fetchedDreams as [AnyObject]?
            } else {
                return nil
            }
        } catch {
            return nil
        }
    }
    
    class func addNewRecoredInDB(_ userDetails: [String : String], user: User){
        user.userId = userDetails["userId"]
        user.firstName  = userDetails["firstName"]
        user.lastName = userDetails["lastName"]
        user.profilePhoto = userDetails["profilePhoto"]
        APP_DELEGATE.saveContext()
    }
    
    class func saveUserDetailsInDB(_ userDetails: [String : String], isForEdit: Bool = false){
        let predicate = NSPredicate(format: "userId == '\(userDetails["userId"] ?? "0")'")
        var user: User!
        if let arrUserList = User.getUserInfoFromContext(params: predicate), arrUserList.count > 0 {
            user = arrUserList.first as? User
        }else{
            if !isForEdit{
                let context = APP_DELEGATE.managedObjectContext
                let entity = NSEntityDescription.entity(forEntityName: "User", in: (context))
                user = User(entity: entity!, insertInto: context)
            }
        }
        if user != nil{
            User.addNewRecoredInDB(userDetails, user: user)
        }
    }
    
}
