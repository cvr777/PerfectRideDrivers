//
//  ListTableCell.swift
//  PerfectRideDrivers
//
//  Created by Harshad.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

class ListTableCell: UITableViewCell {

    @IBOutlet weak var lblTitle1 : UILabel!
    @IBOutlet weak var lblTitle2 : UILabel!
    @IBOutlet weak var lblTitle3 : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
