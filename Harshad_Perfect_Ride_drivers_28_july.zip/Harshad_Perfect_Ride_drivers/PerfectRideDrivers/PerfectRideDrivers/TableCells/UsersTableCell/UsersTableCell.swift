//
//  UsersTableCell.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

class UsersTableCell: UITableViewCell {

    @IBOutlet weak var imgProfile: UIImageView!
    @IBOutlet weak var lblFirstName:UILabel!
    @IBOutlet weak var lblLastName : UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        
        //This used to set circular radius to image
        imgProfile.layer.cornerRadius = 25.0
        imgProfile.layer.masksToBounds = true
        
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
