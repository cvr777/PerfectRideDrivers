//
//  BankInfoViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

//This view controller used to add edit and update bank information
class BankInfoViewController: UIViewController {

    enum ScreenViewType {
        case view
        case edit
        case list
    }
    
    var screenViewType : ScreenViewType = .list
    
    @IBOutlet weak var inputsStackView : UIStackView!
    @IBOutlet weak var addBankInfoBtn : UIButton!
    @IBOutlet weak var branchNumberTxt : UITextField!
    @IBOutlet weak var institutionNumberTxt : UITextField!
    @IBOutlet weak var accountNumberTxt : UITextField!
    
    @IBOutlet weak var tableView: UITableView!
    
    var banksCount = 0
    var bankInfo : Bank?
    var arrBanks : [Bank]?
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        setUpUI()
        tableView.register(UINib(nibName: "ListTableCell", bundle: nil), forCellReuseIdentifier: "ListTableCell")
        switch screenViewType {
        case .edit:
            self.navigationItem.title = "Edit Bank Details"
            addEditNavigationButtons()
            
        case .view:
            self.navigationItem.title = "Bank Details"
            
        case .list:
            self.navigationItem.title = "Bank Details list"
            addNavigationButton()
            
        }
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        switch screenViewType {
        case .edit:
            addBankInfoBtn.isHidden = true
            inputsStackView.isHidden = false
            tableView.isHidden = true
        case .list:
            if let bDetails = Bank.getBankInfoFromContext(params: nil) as? [Bank],bDetails.count > 0{
                arrBanks = bDetails
                tableView.isHidden = false
                tableView.reloadData()
                addBankInfoBtn.isHidden = true
                inputsStackView.isHidden = true
            }else{
                addBankInfoBtn.isHidden = false
                inputsStackView.isHidden = true
                tableView.isHidden = true
            }
        case .view:
            if let bDetails = bankInfo{
                setBankDetails(bDetails)
                inputsStackView.isHidden = false
                addBankInfoBtn.isHidden = true
                tableView.isHidden = true
                branchNumberTxt.isUserInteractionEnabled  = false
                accountNumberTxt.isUserInteractionEnabled  = false
                institutionNumberTxt.isUserInteractionEnabled = false
            }
        
        }
        
    }
    
    //MARK: - Custom methods
    //This method used to set common UI
    func setUpUI(){
        addBankInfoBtn.layer.cornerRadius = 5.0
        addBankInfoBtn.layer.masksToBounds = true
        addBankInfoBtn.layer.borderColor = UIColor.black.cgColor
        addBankInfoBtn.layer.borderWidth = 1.0
    }
    
    //This method used to add cancel and save navigation buttons
    func addEditNavigationButtons(){
        let cancelButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(cancelTapped))
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
        accountNumberTxt.isUserInteractionEnabled = true
        institutionNumberTxt.isUserInteractionEnabled = true
        branchNumberTxt.isUserInteractionEnabled = true
    }
    
    //This method used to add cancel and save navigation buttons
    func addNavigationButton(){
        let editB = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(editTapped))
        self.navigationItem.rightBarButtonItem = editB
        accountNumberTxt.isUserInteractionEnabled = false
        institutionNumberTxt.isUserInteractionEnabled = false
        branchNumberTxt.isUserInteractionEnabled = false
    }
    
    @objc func editTapped(){
        openViewInEditMode()
    }
    
    func openViewInEditMode(){
        guard let bankInfo = self.storyboard?.instantiateViewController(withIdentifier: "BankInfoViewController") as? BankInfoViewController else{return}
        bankInfo.screenViewType = .edit
        bankInfo.banksCount = arrBanks?.count ?? 0
        let navigationController = UINavigationController(rootViewController: bankInfo)
        self.navigationController?.present(navigationController, animated: true, completion: nil)
        
    }
    
    @objc func cancelTapped(){
        self.dismiss(animated: true, completion: nil)
    }
    
    @objc func saveTapped(){
        var dictDetails = [String : String]()
        dictDetails["bankId"] = "\(banksCount+1)"
        dictDetails["BA"] = accountNumberTxt.text ?? ""
        dictDetails["BB"] = branchNumberTxt.text ?? ""
        dictDetails["BI"] = institutionNumberTxt.text ?? ""
        
        Bank.saveBankDetailsInDB(dictDetails)
        self.dismiss(animated: true, completion: nil)
    }
    
    @IBAction func addBankInfoTapped(_ sender : UIButton){
        openViewInEditMode()
    }
    
    func setBankDetails(_ bDetails : Bank){
        branchNumberTxt.text = bDetails.branchNumber
        institutionNumberTxt.text = bDetails.institutionNumber
        accountNumberTxt.text = bDetails.accountNumber
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension BankInfoViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let bankInfo = self.storyboard?.instantiateViewController(withIdentifier: "BankInfoViewController") as? BankInfoViewController , let bank = arrBanks?[indexPath.row] else{return}
        bankInfo.screenViewType = .view
        bankInfo.bankInfo = bank
        self.navigationController?.pushViewController(bankInfo, animated: true)
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
}

extension BankInfoViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrBanks?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableCell", for: indexPath) as! ListTableCell
        guard let bank = arrBanks?[indexPath.row] else {return cell}
        cell.lblTitle1.text = "ACCOUNT NO: \(bank.accountNumber ?? "")"
        cell.lblTitle2.text = "BRANCH NO: \(bank.branchNumber ?? "")"
        cell.lblTitle3.text = "INSTITUTION NO: \(bank.institutionNumber ?? "")"
        return cell
    }
    
}

