//
//  CarDeatilsViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

class CarDeatilsViewController: UIViewController {
    
    enum ScreenViewType {
        case view
        case edit
        case list
    }
    
    var carInfo : Car?
    
    @IBOutlet weak var carInfoStackView : UIStackView!
    
    @IBOutlet weak var yearButton : UIButton!
    @IBOutlet weak var makeButton : UIButton!
    @IBOutlet weak var modelButton : UIButton!
    
    @IBOutlet weak var addCarDetailsButton : UIButton!
    @IBOutlet weak var tableView: UITableView!
    
    var screenViewType : ScreenViewType = .list
    var arrCars : [Car]?
    var carsCount = 1
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.register(UINib(nibName: "ListTableCell", bundle: nil), forCellReuseIdentifier: "ListTableCell")
        tableView.isHidden = false
        switch screenViewType {
        case .edit:
            self.navigationItem.title = "Update Car Details"
            addEditNavigationButtons()
            addCarDetailsButton.isHidden = true
        
        case .view:
            yearButton.isUserInteractionEnabled = false
            modelButton.isUserInteractionEnabled = false
            makeButton.isUserInteractionEnabled = false
            self.navigationItem.title = "Car Details"
            addCarDetailsButton.isHidden = true
        case .list:
            carInfoStackView.isHidden = true
            tableView.isHidden = false
            addCarDetailsButton.isHidden = true
            addNavigationButton()
            self.navigationItem.title = "Cars List"
        }
        
        setUIForEmptyCardDetails()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        if screenViewType == .list{
            if let cDetails = Car.getCarInfoFromContext(params: nil) as? [Car], cDetails.count > 0{
                arrCars = cDetails
                tableView.isHidden = false
                addCarDetailsButton.isHidden = true
                carInfoStackView.isHidden = true
                tableView.reloadData()
            }else{
                addCarDetailsButton.isHidden = false
                carInfoStackView.isHidden = true
                tableView.isHidden = true
            }
            
        }
        
        if screenViewType == .edit{
            addCarDetailsButton.isHidden = true
            carInfoStackView.isHidden = false
            tableView.isHidden = true
        }
        
        if screenViewType == .view{
            addCarDetailsButton.isHidden = true
            carInfoStackView.isHidden = false
            tableView.isHidden = true
            if let cInfo = carInfo{
                setCarDetailsFor(car: cInfo)
                addCarDetailsButton.isHidden = true
                carInfoStackView.isHidden = false
            }
        }
    }
    
    func setCarDetailsFor(car : Car){
        
        yearButton.setTitle(car.year ?? "", for: .normal)
        modelButton.setTitle(car.model ?? "", for: .normal)
        makeButton.setTitle( car.make ?? "", for: .normal)
    }
    
    
    //MARK: - Custom methods
    //This method used to add cancel and save navigation buttons
    func addEditNavigationButtons(){
        let cancelButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(cancelTapped))
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
    }
    
    func setUIForEmptyCardDetails(){
        addCarDetailsButton.layer.cornerRadius = 5.0
        addCarDetailsButton.layer.masksToBounds = true
        addCarDetailsButton.layer.borderColor = UIColor.black.cgColor
        addCarDetailsButton.layer.borderWidth = 1.0
        
    }
    
    //This method used to add cancel and save navigation buttons
    func addNavigationButton(){
        let editB = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(editTapped))
        self.navigationItem.rightBarButtonItem = editB
    }
    
    @objc func editTapped(){
        openViewInEditMode()
    }
    
    
    func openViewInEditMode(){
        guard let editVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CarDeatilsViewController") as? CarDeatilsViewController else {return}
        editVC.screenViewType = .edit
        editVC.carsCount = arrCars?.count ?? 0
        let navigationVC = UINavigationController(rootViewController: editVC)
        self.navigationController?.present(navigationVC, animated: true, completion: nil)
    }
    
    //This method called when user tapped on save button
    @objc func cancelTapped(){
        self.dismiss(animated: true, completion: nil)
    }
    
    //This method called when user tapped on save button
    @objc func saveTapped(){
        var dictDetails = [String : String]()
        dictDetails["carId"] = "\(carsCount+1)"
        dictDetails["year"] = yearButton.titleLabel?.text ?? ""
        dictDetails["make"] = makeButton.titleLabel?.text ?? ""
        dictDetails["model"] = modelButton.titleLabel?.text ?? ""
        
        Car.saveCarDetailsInDB(dictDetails)
        self.dismiss(animated: true, completion: nil)
    }
    
    //This method called when user tapped on add car details button
    @IBAction func addCarDetailsButtonTapped(_ sender : UIButton){
        openViewInEditMode()
    }
    
    //This method called when user tapped on year button
    @IBAction func yearButtonTapped(_ sender : UIButton){
        var arrYears = [String]()
        for year in 2012...2018{
            arrYears.append("\(year)")
        }
        ActionSheetMultipleStringPicker.show(withTitle: "Please Select Year", rows: [
            arrYears
            ], initialSelection: [0], doneBlock: {
                picker, indexes, values in
                let arrVal = values as! [String]
                self.yearButton.setTitle(arrVal[0], for: .normal)
                return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    //This method called when user tapped on make button
    @IBAction func makeButtonTapped(_ sender : UIButton){
        ActionSheetMultipleStringPicker.show(withTitle: "Please Select Car Make", rows: [
            ["BMW", "TATA", "MARUTI", "AUDI"]
            ], initialSelection: [0], doneBlock: {
                picker, indexes, values in
                let arrVal = values as! [String]
                self.makeButton.setTitle(arrVal[0], for: .normal)
                return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    //This method called when user tapped on model button
    @IBAction func modelButtonTapped(_ sender : UIButton){
        ActionSheetMultipleStringPicker.show(withTitle: "Please Select Car Model", rows: [
            ["Q1", "Q2", "J6", "R7","R5"]
            ], initialSelection: [0], doneBlock: {
                picker, indexes, values in
                let arrVal = values as! [String]
                self.modelButton.setTitle(arrVal[0], for: .normal)
                return
        }, cancel: { ActionMultipleStringCancelBlock in return }, origin: sender)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension CarDeatilsViewController: UITableViewDelegate{
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        guard let detailsVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "CarDeatilsViewController") as? CarDeatilsViewController, let car = arrCars?[indexPath.row] else {return}
        detailsVC.screenViewType = .view
        
        detailsVC.carInfo = car
        self.navigationController?.pushViewController(detailsVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
}

extension CarDeatilsViewController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrCars?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ListTableCell", for: indexPath) as! ListTableCell
        guard let car = arrCars?[indexPath.row] else {return cell}
        cell.lblTitle1.text = "YEAR : \(car.year ?? "")"
        cell.lblTitle2.text = "MAKE : \(car.make ?? "")"
        cell.lblTitle3.text = "MODEL : \(car.model ?? "")"
        return cell
        
    }
    
}

