//
//  EditProfileViewController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

//This view contoller is used to edit details of user
class EditProfileViewController: UIViewController {

    @IBOutlet weak var userProfileButton : UIButton!
    @IBOutlet weak var firstNameTxt : UITextField!
    @IBOutlet weak var lastNameTxt : UITextField!
    var selectedImage : UIImage?
    let picker = UIImagePickerController()
    var usersCount  = 0
    
    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()
        addNavigationButtons()
    }
    
    //MARK: - Custom methods
    //This method used to add cancel and save navigation buttons
    func addNavigationButtons(){
        self.navigationItem.title = "Add User Details"
        let cancelButton = UIBarButtonItem(title: "Back", style: .plain, target: self, action: #selector(cancelTapped))
        let saveButton = UIBarButtonItem(title: "Save", style: .plain, target: self, action: #selector(saveTapped))
        self.navigationItem.leftBarButtonItem = cancelButton
        self.navigationItem.rightBarButtonItem = saveButton
        
        userProfileButton.layer.cornerRadius = 75.0
        userProfileButton.layer.masksToBounds = true
        userProfileButton.layer.borderColor = UIColor.black.cgColor
        userProfileButton.layer.borderWidth = 1.0
    }
    
    //This method used to get image from string
    func getImageFromString(strBase64 : String?) -> UIImage?{
        guard let imageString = strBase64 else{return nil}
        guard let dataDecoded : Data = Data(base64Encoded: imageString, options: .ignoreUnknownCharacters) else{return nil}
        let decodedimage = UIImage(data: dataDecoded)
        return decodedimage
    }
    
    //This method used to close edit profile screen
    @objc func cancelTapped(){
        self.dismiss(animated: true, completion: nil)
    }
    
    //This method used to save user details
    @objc func saveTapped(){
        var dictDetails = [String : String]()
        dictDetails["userId"] = "\(usersCount + 1)"
        dictDetails["lastName"] = lastNameTxt.text ?? ""
        dictDetails["firstName"] = firstNameTxt.text ?? ""
        dictDetails["profilePhoto"] = getStringFrom(image: selectedImage != nil ? selectedImage! : UIImage(named: "profile")!)
        User.saveUserDetailsInDB(dictDetails)
        self.dismiss(animated: true, completion: nil)
    }
    
    func getStringFrom(image : UIImage) -> String {
        guard let imageData:NSData = UIImagePNGRepresentation(image) as NSData? else{return ""}
        let strBase64 = imageData.base64EncodedString(options: .lineLength64Characters)
        return strBase64
    }
    
    //This method called when user tapped on profile image
    @IBAction func userprofileButtonTapped(_ sender : UIButton){
        picker.allowsEditing = false
        //Checking camera availability
        if UIImagePickerController.isSourceTypeAvailable(.camera){
            picker.sourceType = .camera
        }else{
            picker.sourceType = .photoLibrary
        }
        
        picker.delegate = self
        present(picker, animated: true, completion: nil)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension EditProfileViewController : UIImagePickerControllerDelegate,UINavigationControllerDelegate{
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [String : Any]) {
        guard let chosenImage = info[UIImagePickerControllerOriginalImage] as? UIImage else{
            dismiss(animated: true, completion: nil)
            return
        }
        // use the image
        userProfileButton.setImage(chosenImage, for: .normal)
        selectedImage = UIImage(data: chosenImage.jpeg(.medium)!)
        dismiss(animated: true, completion: nil)
    }
    
    func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
        dismiss(animated: true, completion: nil)
    }
}


extension UIImage {
    enum JPEGQuality: CGFloat {
        case lowest  = 0
        case low     = 0.25
        case medium  = 0.5
        case high    = 0.75
        case highest = 1
    }
    
    /// Returns the data for the specified image in JPEG format.
    /// If the image object’s underlying image data has been purged, calling this function forces that data to be reloaded into memory.
    /// - returns: A data object containing the JPEG data, or nil if there was a problem generating the data. This function may return nil if the image has no data or if the underlying CGImageRef contains data in an unsupported bitmap format.
    func jpeg(_ quality: JPEGQuality) -> Data? {
        return UIImageJPEGRepresentation(self, quality.rawValue)
    }
}

