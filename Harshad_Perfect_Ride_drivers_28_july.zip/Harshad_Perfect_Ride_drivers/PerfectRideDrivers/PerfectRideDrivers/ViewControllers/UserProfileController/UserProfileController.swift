//
//  UserProfileController.swift
//  PerfectRideDrivers
//
//  Created by CompanyName.
//  Copyright © 2018 com.companyname.harshad. All rights reserved.
//

import UIKit

class UserProfileController: UIViewController {

    enum ScreenType {
        case view
        case list
    }
    
    var screenType : ScreenType = .list
    @IBOutlet weak var firstNameLabel : UILabel!
    @IBOutlet weak var lastNameLabel : UILabel!
    @IBOutlet weak var profileImage : UIImageView!
    
    @IBOutlet weak var addUserDetailsBtn : UIButton!
    @IBOutlet weak  var detailsView: UIView!
    
    @IBOutlet weak var tableView: UITableView!
    
    var arrUsers : [User]?
    var currentUser : User?
    
    var isListScreen : Bool = true

    //MARK: - View Controller life cycle
    override func viewDidLoad() {
        super.viewDidLoad()

        setUI()
        tableView.register(UINib(nibName: "UsersTableCell", bundle: nil), forCellReuseIdentifier: "UsersTableCell")
        // Do any additional setup after loading the view.
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        switch screenType {
        case .list:
            self.navigationItem.title = "Users List"
            getUserDetails()
            addNavigationButtons()
            detailsView.isHidden = true
            
        case .view:
            guard let cUser = currentUser else{return}
            self.navigationItem.title = "User Profile"
            setUserDetails(user: cUser)
            tableView.isHidden = true
            detailsView.isHidden = false
            
        }
        
        
    }
    
    //MARK: - Custom methods
    //This method used to set round corner radius to profile button
    func setUI(){
        profileImage.layer.cornerRadius = 75.0
        profileImage.layer.masksToBounds = true
        profileImage.layer.borderColor = UIColor.black.cgColor
        profileImage.layer.borderWidth = 1.0
        addUserDetailsBtn.layer.cornerRadius = 5.0
        addUserDetailsBtn.layer.masksToBounds = true
        addUserDetailsBtn.layer.borderColor = UIColor.black.cgColor
        addUserDetailsBtn.layer.borderWidth = 1.0
        
    }
    
    //This method used to get user details from core data
    func getUserDetails(){
        if let userDetails = User.getUserInfoFromContext(params: nil) as? [User], userDetails.count > 0 {
            arrUsers = userDetails
            tableView.reloadData()
            tableView.isHidden = false
            addUserDetailsBtn.isHidden = true
        }else{
            detailsView.isHidden = true
            tableView.isHidden = true
            addUserDetailsBtn.isHidden = false
        }

    }
    
    //This method used to set user details
    func setUserDetails(user : User){
        lastNameLabel.text = user.lastName
        firstNameLabel.text = user.firstName
        profileImage.image = getImageFromString(strBase64: user.profilePhoto)
        
    }
    
    //This method used to get image from string
    func getImageFromString(strBase64 : String?) -> UIImage?{
        guard let imageString = strBase64 else{return nil}
        guard let dataDecoded : Data = Data(base64Encoded: imageString, options: .ignoreUnknownCharacters) else{return nil}
        let decodedimage = UIImage(data: dataDecoded)
        return decodedimage
    }
    
    //This method used to add cancel and save navigation buttons
    func addNavigationButtons(){
        let editButton = UIBarButtonItem(title: "Add", style: .plain, target: self, action: #selector(editTapped))
        self.navigationItem.rightBarButtonItem = editButton
        
    }
    
    //This method used to open edit user profile screen
    @objc func editTapped(){
        openEditScreen()
        
    }
    
    //This method called when user tapped on add user details button
    @IBAction func addUserDetailsTapped(_ sender : UIButton){
        openEditScreen()
    }
    
    //This method used to open edit screen
    func openEditScreen(){
        guard let editVC = UIStoryboard.init(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "EditProfileViewController") as? EditProfileViewController else {return}
        editVC.usersCount = arrUsers?.count ?? 0
        let navigationVC = UINavigationController(rootViewController: editVC)
        self.navigationController?.present(navigationVC, animated: true, completion: nil)
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
}

extension UserProfileController: UITableViewDelegate{
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        guard let profileVC = self.storyboard?.instantiateViewController(withIdentifier: "UserProfileController") as? UserProfileController, let user = arrUsers?[indexPath.row] else{return}
        profileVC.currentUser = user
        profileVC.screenType = .view
        self.navigationController?.pushViewController(profileVC, animated: true)
    }
    
    func tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
        return 70
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableViewAutomaticDimension
    }
    
}

extension UserProfileController: UITableViewDataSource{
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arrUsers?.count ?? 0
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "UsersTableCell", for: indexPath) as! UsersTableCell
        guard let user = arrUsers?[indexPath.row] else {return cell}
        cell.imgProfile.image = getImageFromString(strBase64: user.profilePhoto)
        cell.lblFirstName.text = user.firstName ?? ""
        cell.lblLastName.text = user.lastName ?? ""
        return cell
        
    }
}
